// import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  HomePageState createState() {
    return HomePageState();
  }
}

class HomePageState extends State<HomePage> {

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Home"),),
      body: ListView(
        children: [
          Container(
            padding: const EdgeInsets.all(15.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Row(
                  //   children: [
                      TextFormField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(

                          ),
                            hintText: "Task Name"
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {   // Validation Logic
                            return 'Please enter some text';
                          }
                          return null;
                        },
                      ),
                  //   ],
                  // ),
                  // Row(
                  //   children: [

                  SizedBox(height: 20,),
                      TextFormField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(

                            ),
                            hintText: "Task Description"
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {   // Validation Logic
                            return 'Please enter some text';
                          }
                          return null;
                        },
                      ),
                  //   ],
                  // ),
                 Row(
                   mainAxisAlignment: MainAxisAlignment.end
                   ,
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(vertical: 16.0),
                       child: ElevatedButton(
                         onPressed: () {
                           if (_formKey.currentState!.validate()) {
                             ScaffoldMessenger.of(context).showSnackBar(
                               const SnackBar(content: Text('Processing Data')),
                             );
                           }
                         },
                         child: const Text('Submit'),
                       ),
                     )
                   ],
                 ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}