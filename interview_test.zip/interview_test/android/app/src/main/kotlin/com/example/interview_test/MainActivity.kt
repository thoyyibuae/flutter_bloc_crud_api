package com.example.interview_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
